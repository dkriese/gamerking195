<div id="clouds" class="clouds"></div>
                    <div class="mountains mountains2">
                        <div class="mountains mountains1">
                            <div class="beast beast_small" id="beast_small"></div>
                            <div class="grass1">
                                <div class="beast beast_big" id="beast_big"></div>
                                <div class="bushes">
                                    <div class="bush1">
                                        <div class="bush2"></div>
                                    </div>
                                    <div class="grass2"></div></div></div>
                        </div>
                    </div><!-- FLOATBOX START -->
                <div class="floatbox" id="floatbox">
                    <h1 class="logo"><img src="http://gamerking195.com/wp-content/themes/bootstrapwp-87-minecraft/img/GamerKingBanner.jpg" alt="Caden"></h1>
                    <h2 class="intro_message">Welcome to the KingCraft Server Forums</h2>
                    <!-- Header Content / Intro Area Start -->
                    <div id="highlight">Play Now at Pvp.KingCraftMC.Net</div>
                    <!-- Header Content / Intro Area Start  END -->
                    <!-- SOCIAL START -->
                        <section class="social">
                          <p>
                           <span class="follow-text">Follow us</span>                            <a href="https://twitter.com/kingcraftpvp" class="twitter social-link"></a>                            <a href="http://www.youtube.com/user/GamerKing195" class="youtube social-link"></a><a href="https://plus.google.com/u/0/104428574158798017612/posts" class="googleplus social-link"></a><a href="http://www.planetminecraft.com" class="pmc social-link"></a>
</p>
</section>
                    <!-- SOCIAL END -->
                </div>
                <!-- FLOATBOX END -->
            </div>
            <!-- SCENERY END --><!-- CONTENT START --><section class="content-area" id="content-area">
        <div class="container">
            <div class="row">
                <!-- COLUMN 1 START (ABOUT US) --><section class="span8 content-section"><h2 class="section-title">Latest Server News</h2>
				<!------------------------------------------------------------------------------------------------------------------------- 
                You can place ANY text or additional code in this section, this section of the website will hold the main content you wish
                to share with your users. I Personally suggest leaving it as a NEWS section, you can add links, small images and more to 
                this section, just make sure it looks okay when you publish and doesnt mess up the website template.
                -------------------------------------------------------------------------------------------------------------------------->
                    <p><h4>Header here</h4></p>
                    <p>Some text here</p>
                    <!-----------------------------------------------------
                    The <hr> tag is what makes the white line between posts
                    ------------------------------------------------------>
                    <hr>
                    <p><h4>Another heading</h4></p>
                    <p>Another description</p>
                    <hr>
                    <p><h4>Third Heading</h4></p>		
                    <p>Third description</p>
                </section><!-- COLUMN 1 END (ABOUT US)--><!-- COLUMN 2 START (SCREENSHOTS) -->
                <section class="span4 content-section"><h2 class="section-title">Screenshots</h2>
                    <div class="thumbnails-holder">
		        <!-- THUMBS START -->
			<div class="thumb" title="Hub">
			   <a href="images/Hub.png" data-rel="prettyPhoto[gal]"><img src="images/thumbs/thmb_Hub.png" alt="The Hub"></a>
			</div>
								  <div class="thumb" title="Arcade">
									  <a href="images/Arcade.png" data-rel="prettyPhoto[gal]"><img src="images/thumbs/thmb_Arcade.png" alt="Arcade"></a>
								  </div>

								<div class="thumb" title="Kit PvP Lobby">
									<a href="images/KitPvPLobby.png" data-rel="prettyPhoto[gal]"><img src="images/thumbs/thmb_KitPvPLobby.png" alt="Kit PvP Lobby"></a>
								</div>
								<div class="thumb" title="Kit PvP">
									<a href="images/KitPvP.png" data-rel="prettyPhoto[gal]"><img src="images/thumbs/thmb_KitPvP.png" alt="Kit PvP"></a>
								</div>

								<div class="thumb" title="Hunger Games">
									<a href="images/HungerGames.png" data-rel="prettyPhoto[gal]"><img src="images/thumbs/thmb_HungerGames.png" alt="Hunger Games"></a>
								</div>
								<div class="thumb" title="Factions">
									<a href="images/FactionsSpawn.png" data-rel="prettyPhoto[gal]"><img src="images/thumbs/thmb_FactionsSpawn.png" alt="Factions"></a>
								</div>

								<!-- THUMBS END -->
							</div><!-- .thumbnails-holder -->
                    <h2 class="section-title">Latest tweets</h2>
                    <a class="twitter-timeline" href="https://twitter.com/kingcraftpvp" data-widget-id="345699752651931648">Tweets by @KingCraftPvP</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

                </section>
                <!-- COLUMN 2 END (SCREENSHOTS) -->
            </div>
            <!-- .row -->
        </div>
        <!-- .container -->
    </section>
    <!-- CONTENT END-->
<!-- FOOTER START -->
    <footer class="page-footer">
        <div class="footer-top-bg"></div>
        <div class="footer-content-wrapper">
        <!----------------------------------------------------------------------------------- 
        To use this Template you NEED TO KEEP the Designed By sycoinc link in the footer.
        Without this in the footer i ask you do not use this template UNLESS HEAVILY EDITED.
        Since this is a free Template this is all i ask when you use this.
        ------------------------------------------------------------------------------------>
            <div class="footer-content">
                <!-- FOOTER CONTENT START -->
                Server Name &copy; 2013 - Template Designed by <a href="http://www.minecraftwebsitetemplates.com">sycoinc</a>
                <!-- FOOTER CONTENT END -->
            </div>
        </div>
    </footer>
    <!-- FOOTER END -->
			<!-- SCRIPTS AND TECHNICAL STUFF -->
			<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
			<script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
			<script src="js/jquery.countdown.min.js"></script>
			<script src="js/jquery.backgroundpos.min.js"></script>
			<script src="js/jquery.tweet.js"></script>
			<script src="js/jquery.prettyPhoto.js"></script>
			<script src="js/script.js"></script>

			<script src="js/bootstrap.min.js"></script>

			<div id="fake_timer" style="display:none"></div>
			<div class="pattern"></div>